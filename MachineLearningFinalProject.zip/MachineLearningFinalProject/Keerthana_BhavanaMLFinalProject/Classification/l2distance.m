function D=l2distance(x1,x2)

if (nargin==1) 
	G=innerproduct(x1);
    P=diag(diag(G))*ones(size(G));
    D=(P+P')-(2*G);
    D=sqrt(D);
else 
   First=innerproduct(x1,x2);
   Second=innerproduct(x1);
   Second=diag(diag(Second))*ones(size(First));
   Third=innerproduct(x2);
   Third=diag(diag(Third))*ones(size(First'));
   Third=Third';
   D=Second+Third-2*First;
   D=sqrt(D);
end;
%


