function preds=knnclassifier(xTr,yTr,xTe,k);

temp=findknn(xTr,xTe,k);
label=yTr(temp);
if(k>1)
[a1 a2 a3]=mode(label);
[TEMP,TEMP_INDEX]=sort(a2);
TEMP1=TEMP-ones(size(a2));
firstIndex=find(TEMP1==(k-2));
if(isempty(firstIndex))
    preds=label(1,:);
else
firstIndex=firstIndex(1:1);
TEMP_INDEX=TEMP_INDEX(:,[1:firstIndex-1]);
firstRow=label(1,:);
replaceValues=firstRow(TEMP_INDEX);
a1(TEMP_INDEX)=replaceValues;
preds=a1;
end;
else
preds=label;
end;
