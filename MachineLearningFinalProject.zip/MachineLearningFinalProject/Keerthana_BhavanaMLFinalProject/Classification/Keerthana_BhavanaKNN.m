function [freds] = Keerthana_BhavanaKNN(xTr,yTr)
%MAIN Summary of this function goes here
%   Detailed explanation goes here

xTr=xTr';
yTr=yTr';
freds=[];
for j=1:20
    %pause(1);
    itr=ismember(1:length(yTr),randsample(1:length(yTr),ceil(0.8*length(yTr))));
    traindata=xTr(:,itr);
    trainlabel=yTr(:,itr);
    xTv=xTr(:,~itr);
    yTv=yTr(:,~itr);
    %disp(yTv);
    accuracy=[];
    for i=1:5
        preds=knnclassifier(traindata,trainlabel,xTv,i);
        result=analyze('acc',yTv,preds);
        accuracy(i,:)=result;
    end
freds=[freds accuracy];


end;
% preds=knnclassifier(xTr,yTr,xTe,3);
% preds=preds';
disp(freds);
freds=mean(freds,2);

end

