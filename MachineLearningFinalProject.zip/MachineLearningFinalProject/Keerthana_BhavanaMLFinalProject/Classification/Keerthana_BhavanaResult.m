function [preds] = Keerthana_BhavanaResult(xTr,yTr,xTe,k)
%MAIN Summary of this function goes here
%   Detailed explanation goes here

xTr=xTr';
yTr=yTr';
xTe=xTe';

preds=knnclassifier(xTr,yTr,xTe,k);
preds=preds';


end

