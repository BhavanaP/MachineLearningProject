function G=innerproduct(x1,x2)


if (nargin==1) % case when there is only one input (x1)
	G=x1'*x1;

else  % case when there are two inputs (x1,x2)
	G=x1'*x2;

end;



