function output=analyze(kind,truth,preds)	

switch kind
   case 'acc' 
		resultarray=truth-preds;
        temparray=(resultarray(:)==0);
        correct=sum(temparray(:)==1);
        output=correct/(length(truth));
		 	
end;

