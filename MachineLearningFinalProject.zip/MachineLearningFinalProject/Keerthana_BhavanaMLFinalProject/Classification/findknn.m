function [indices,dists]=findknn(xTr,xTe,k);


dists=l2distance(xTe,xTr);
[Temp,Index]=sort(dists,2);
Index=Index(:,[1:k]);
indices=Index';
	
	

	
