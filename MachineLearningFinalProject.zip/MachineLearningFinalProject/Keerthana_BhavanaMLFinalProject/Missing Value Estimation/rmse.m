function [ error ] = rmse( x,y )
%RMSE Summary of this function goes here
%   Detailed explanation goes here

error=sum(sqrt(mean((x-y).^2)));
end

